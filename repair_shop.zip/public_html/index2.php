<?php
// Activation de l'affichage des erreurs pour le débogage
ini_set('display_errors', 1);
error_reporting(E_ALL);

// Extraction des variables ID et clé hash de l'URL
$id = $_GET['id'] ?? 'Inconnu';
$key = $_GET['key'] ?? '';

// Connexion à la base de données via des variables d'environnement
$username = 'boal5601_NumDossier';
$password = '@g*KTe0LUBZF8fr!';
$dbname = 'boal5601_BDD_Dossiers_RDD';
$servername = 'localhost';

// Création de la connexion à la base de données
$conn = new mysqli($servername, $username, $password, $dbname);

// Vérification de la connexion
if ($conn->connect_error) {
    die("Connexion échouée : " . $conn->connect_error);
}

// Requête SQL pour vérifier l'existence du dossier et la correspondance du hash
$query = "SELECT * FROM dossiers WHERE num_dossier = ? AND hash = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("is", $id, $key);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    // Aucun dossier trouvé ou le hash ne correspond pas
    echo 'Dossier introuvable';
    exit; // Arrêter l'exécution si le dossier est introuvable ou si le hash ne correspond pas
}

// Dossier trouvé, extraction des données
$data = $result->fetch_assoc();

$stmt->close();
$conn->close();
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $id; ?> - Dossier de récupération de données</title>
    <link rel="stylesheet" href="style.css">
	
	<svg style="display:none;">
    <!-- Icône utilisateur -->
    <symbol id="user-icon" viewBox="0 0 24 24">
        <path d="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z"/>
    </symbol>
    <!-- Icône email -->
    <symbol id="email-icon" viewBox="0 0 24 24">
        <path d="M20 4H4c-1.1 0-1.99.9-1.99 2L2 18c0 1.1.89 2 1.99 2H20c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm0 4-8 5-8-5V6l8 5 8-5v2z"/>
    </symbol>
    <!-- Icône téléphone -->
    <symbol id="phone-icon" viewBox="0 0 24 24">
        <path d="M6.62 10.79c1.44 2.83 3.76 5.14 6.59 6.59l2.2-2.2c.27-.27.67-.36 1.02-.24 1.12.37 2.33.57 3.57.57.55 0 1 .45 1 1V20c0 .55-.45 1-1 1C9.92 21 3 14.08 3 6c0-.55.45-1 1-1h3.5c.55 0 1 .45 1 1 0 1.24.2 2.45.57 3.57.12.35.03.75-.24 1.02l-2.21 2.2z"/>
    </symbol>
    <!-- Icône adresse -->
    <symbol id="address-icon" viewBox="0 0 24 24">
        <path d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zm0 9.5c-1.38 0-2.5-1.12-2.5-2.5S10.62 6.5 12 6.5 14.5 7.62 14.5 9 13.38 11.5 12 11.5z"/>
    </symbol>
    <!-- Icône position/poste -->
    <symbol id="position-icon" viewBox="0 0 24 24">
        <path d="M12 7c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2zm0 10c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z"/>
    </symbol>
</svg>

</head>
<body>
    <header class="main-header">
        <div class="title-bar">
            <h1 style="font-size: 24px;">Dossier de récupération de données N°<?php echo $id; ?></h1>
            <span class="date"><?php echo date("d/m/Y"); ?></span>
        </div>
        <div class="info-bar">
    <img src="./logo.jpg" alt="Logo" class="logo">
    <div class="client-info">
        <h3 class="info-title">Vos informations</h3>
        <div>
		<svg class="icon"><use xlink:href="#user-icon"></use></svg>
		<?php
		// Affichage du prénom et nom
		echo htmlspecialchars($data['prenom']) . ' ' . htmlspecialchars($data['nom']);

		// Vérification si 'nom_societe' n'est pas null et affichage conditionnel
		if (!empty($data['nom_societe'])) {
			echo ' - ' . htmlspecialchars($data['nom_societe']);
		}
			?>
		</div>

        <div><svg class="icon"><use xlink:href="#email-icon"></use></svg>Email: <?php echo htmlspecialchars($data['email']); ?></div>
        <div><svg class="icon"><use xlink:href="#phone-icon"></use></svg>Tel: <?php echo htmlspecialchars($data['telephone']); ?></div>
        <div><svg class="icon"><use xlink:href="#address-icon"></use></svg>Adresse: <?php echo htmlspecialchars($data['adresse_complete']); ?></div>
    </div>
    <div class="tech-info">
        <h3 class="info-title">Votre technicien dédié</h3>
        <div><svg class="icon"><use xlink:href="#user-icon"></use></svg>Expert: Alexandre Bongrand</div>
        <div><svg class="icon"><use xlink:href="#position-icon"></use></svg>Poste: Responsable des services techniques</div>
        <div><svg class="icon"><use xlink:href="#email-icon"></use></svg>Email: datarecovery@sauve-souris.fr</div>
        <div><svg class="icon"><use xlink:href="#phone-icon"></use></svg>Téléphone: 06.79.90.56.15</div>
    </div>
</div>
    </header>
 <section class="support">
        <h2>Support et Données</h2>
        <p><strong>Type de support : </strong><?php echo htmlspecialchars($data['type_media']); ?></p>
        <p><strong>Données à récupérer en priorité : </strong><?php echo htmlspecialchars($data['donnees_importante']); ?></p>
        
        <p class="titleForm"><strong>Confirmez l'existence d'un mot de passe : </strong></p>
        <input type="radio" id="passwordYes" name="passwordPresence" value="Yes" 
               <?php echo ($data['donnees_cryptee'] == 'Yes') ? 'checked' : ''; ?>
               onchange="handlePasswordPresenceChange('Yes')">
        <label for="passwordYes">J'ai un mot de passe</label>

        <input type="radio" id="passwordNo" name="passwordPresence" value="No" 
               <?php echo ($data['donnees_cryptee'] == 'No') ? 'checked' : ''; ?>
               onchange="handlePasswordPresenceChange('No')">
        <label for="passwordNo">Je n'ai pas de mot de passe</label>

        <div id="passwordFields" style="display:none;">
            <p class="titleForm"><strong>Nom du logiciel ou de l'outil de cryptage :</strong></p>
            <input type="text" id="encryptionSoftware" name="encryptionSoftware" placeholder="Exemple : Bitlocker / TrueCrypt / VeraCrypt" style="width:50%; height: 20px;">
            <p class="titleForm"><strong>Mot de passe / Clé sécurisée :</strong></p>
            <textarea id="secureKey" name="secureKey" style="width:50%; height: 20px;" required></textarea>
			<p id="errorMessage" style="color:red;display:none;">N'oubliez pas de nous donner le mot de passe ou la clé sécurisée</p>
        </div>
        
        <p class="titleForm"><strong>Compléments d'information :</strong></p>
        <textarea id="additionalInfo" name="additionalInfo" onclick="prepareTextArea()" onfocus="prepareTextArea()">
<?php echo trim(htmlspecialchars($data['symptomes'])); ?>
</textarea>

    

    
</section>
       
    <section class="forfait">
        <h2>Notre forfait sans engagement</h2>
        <p><strong>Délais de traitement :</strong> 5 à 15 jours ouvrés, après réception de votre média</p> 
		<p><strong>Prix du forfait :</strong> <?php echo htmlspecialchars($data['valeur_prix']); ?>€ TTC<br></p>
		<div class="info-box">
    <svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" fill="currentColor" class="info-icon" viewBox="0 0 16 16">
                <path d="M8 16A8 8 0 1 1 8 0a8 8 0 0 1 0 16zm0-1A7 7 0 1 0 8 1a7 7 0 0 0 0 14zm.93-12a.87.87 0 1 1-1.75 0 .87.87 0 0 1 1.75 0zM8 6a1 1 0 0 1 1 1v5a1 1 0 0 1-2 0V7a1 1 0 0 1 1-1z"/>
    </svg>
    <p>Le paiement est dû uniquement si la récupération des données est techniquement possible et une fois que vous avez validé la liste interactive des fichiers que nous pouvons récupérer.</p>
</div>
	
    </section>
	
	
    <section class="acheminement">
        <h2>Acheminement du support</h2>
        <form id="shipmentForm">
            <label><input type="radio" name="shipmentMethod" value="boite_aux_lettres" required> Je conditionne mon support et le dépose dans ma boîte aux lettres.</label><br>
            <label><input type="radio" name="shipmentMethod" value="bureau_de_poste" required> Je conditionne mon support et le dépose dans un bureau de Poste.</label><br>
            <p id="shipmentMethodError" style="color: red; display: none;">La méthode d'acheminement de votre média est requise</p>
        </form>
		<div class="info-box">
    <svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" fill="currentColor" class="info-icon" viewBox="0 0 16 16">
        <path d="M8 16A8 8 0 1 1 8 0a8 8 0 0 1 0 16zm0-1A7 7 0 1 0 8 1a7 7 0 0 0 0 14zm.93-12a.87.87 0 1 1-1.75 0 .87.87 0 0 1 1.75 0zM8 6a1 1 0 0 1 1 1v5a1 1 0 0 1-2 0V7a1 1 0 0 1 1-1z"/>
    </svg>
    <p>IMPORTANT : Veuillez vous assurer que chaque colis envoyé comporte l'étiquette d'expédition ou, en son absence, que le numéro de dossier soit clairement indiqué sur le carton ou à l'intérieur afin de faciliter le suivi du colis tout au long du processus.</p>
</div>
		
		
    </section>
	
	<section class="validation">
        <!-- Ajout de la case à cocher pour les termes et conditions -->
        <form id="validationForm" method="POST" action="">
            <input type="checkbox" id="termsCheckbox" name="termsAcceptance" required>
            <label for="termsCheckbox">En cochant cette case, j'autorise Sauve-Souris et ses partenaires à intervenir sur mon support. Je déclare avoir pris connaissance et accepté les <a href="https://www.sauve-souris.fr/termes-et-conditions/" target="_blank">termes et conditions de services</a>. J'accepte que les informations saisies dans ce formulaire soient utilisées conformément au RGPD pour gérer la relation commerciale qui peut en découler.</label>
            <div id="termsError" style="color: red; padding-top: 8px;display: none;">Vous devez accepter les termes et conditions pour continuer.</div>	 
        </form>
		<div style="text-align: center;padding: 20px;">
		 <button type="submit" id="submitButton" style="background-color: #e67e22;color: white;padding: 15px 60px;border: none;border-radius: 5px;cursor: pointer;font-size: 22px;">Finaliser mon dossier</button>
		 </div>
    </section>
	
	

<script>
    // Initialisation : mise à jour de l'affichage des champs liés au mot de passe et validation de leur présence
    document.addEventListener('DOMContentLoaded', function () {
    updatePasswordFieldsDisplay();
    validatePasswordPresence();
});

    // Gère le changement de l'état des radios concernant la présence d'un mot de passe
    function handlePasswordPresenceChange(value) {
    updatePasswordFieldsDisplay();
    validatePasswordPresence();
}

    // Met à jour l'affichage des champs pour le mot de passe en fonction de l'option sélectionnée
    function updatePasswordFieldsDisplay() {
    var passwordYesChecked = document.getElementById('passwordYes').checked;
    document.getElementById('passwordFields').style.display = passwordYesChecked ? 'block' : 'none';
}

    // Vérifie si une option concernant la présence du mot de passe est sélectionnée et affiche un message d'erreur si ce n'est pas le cas
    function validatePasswordPresence() {
    var passwordYes = document.getElementById('passwordYes');
    var passwordNo = document.getElementById('passwordNo');
    var errorMessage = document.getElementById('errorMessage');
    
    if (!passwordYes.checked && !passwordNo.checked) {
        errorMessage.style.display = 'block';
    } else {
        errorMessage.style.display = 'none';
    }
	}

    // Prépare le champ de texte pour les informations supplémentaires au clic
    function prepareTextArea() {
    var textArea = document.getElementById('additionalInfo');
    if (textArea.value === "<?php echo htmlspecialchars($data['symptomes']); ?>") {
        textArea.value += "\n";
    }
}
</script>

<script>
document.getElementById('submitButton').addEventListener('click', function(event) {
    event.preventDefault(); // Prevent form submission to handle validations

    var errors = [];
    var termsAccepted = document.getElementById('termsCheckbox').checked; // Récupération de l'état de la case à cocher des termes
    var shipmentMethod = document.querySelector('input[name="shipmentMethod"]:checked');
    var passwordYes = document.getElementById('passwordYes').checked;
    var secureKey = document.getElementById('secureKey').value.trim();

    // Check if terms and conditions are accepted
    if (!termsAccepted) {
        document.getElementById('termsError').style.display = 'block';
        errors.push("Vous devez accepter les termes et conditions pour continuer.");
    } else {
        document.getElementById('termsError').style.display = 'none';
    }

    // Check if shipment method is selected
    if (!shipmentMethod) {
        document.getElementById('shipmentMethodError').style.display = 'block';
        errors.push("La méthode d'acheminement de votre média est requise.");
    } else {
        document.getElementById('shipmentMethodError').style.display = 'none';
    }

    // Check if secureKey is provided when passwordYes is checked
    if (passwordYes && secureKey === '') {
        document.getElementById('errorMessage').style.display = 'block';
        errors.push("Le mot de passe / la clé sécurisée est requise.");
    } else {
        document.getElementById('errorMessage').style.display = 'none';
    }

    // If there are errors, show alert and prevent form submission
    if (errors.length > 0) {
        alert("Erreurs:\n" + errors.join("\n"));
        return false;
    }

    // If all validations pass, proceed with data submission
    submitData();
});

function submitData() {
    var encryptionSoftware = document.getElementById('encryptionSoftware').value;
    var secureKey = document.getElementById('secureKey').value;
    var additionalInfo = document.getElementById('additionalInfo').value;
    var hasPassword = document.getElementById('passwordYes').checked ? 'Yes' : 'No';
    var shipmentMethod = document.querySelector('input[name="shipmentMethod"]:checked').value;

    var data = {
        id: '<?php echo $id; ?>',
        encryptionSoftware: encryptionSoftware,
        secureKey: secureKey,
        additionalInfo: additionalInfo,
        hasPassword: hasPassword,
        shipmentMethod: shipmentMethod
    };
console.log(data);
    fetch('https://hook.eu2.make.com/22trevp2stnhe1nkpqgjqacvh1xgil2a', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(data)
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('HTTP status ' + response.status);
        }
       
        return response.text(); // Handling non-JSON responses
    })
    .then(text => {
        
        console.log('Success:', text);
        alert('Informations envoyées avec succès !');
    })
    .catch((error) => {
        console.error('Error:', error);
        alert('Erreur lors de l\'envoi des informations. Vérifiez la console pour plus de détails.');
    });
}
</script>


</body>
</html> 
